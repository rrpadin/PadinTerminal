"""
Core boilerplate modules
"""
