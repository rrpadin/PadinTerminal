# Business Directory

**Put all your custom business logic here.**

## Structure:
- `backend/routes/` - Your API endpoints
- `frontend/pages/` - Your React pages  
- `config/` - Your business configuration

## The boilerplate auto-loads everything from this directory.

See `../directives/BUILD_DIRECTIVE.md` for complete instructions.
